INSTALL:
1. Upload all files in this folder to an HTTPS static hosting service.
2. Open the HTTPS site in Chrome on Android.
3. Tap INSTALL APP if shown, or Chrome menu -> Add to Home screen / Install app.
4. The app will open full-screen like an Android app.

This is signal-only and does not connect to Olymptrade or place orders.
